#!/usr/bin/env python3

import os
import requests
import logging

logging.basicConfig(
    level=logging.INFO,
    format='[%(levelname)s] %(asctime)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

RAW_DATA_DIR = "raw_data"
STATION_IDS = [26953, 31688]
YEARS = [2023, 2024]
MONTHS = range(1, 13)

def download_weather_csv(station_id, year, month, out_path):
    base_url = (
        "https://climate.weather.gc.ca/climate_data/bulk_data_e.html?"
        "format=csv&time=LST&timeframe=1&submit=Download+Data"
    )
    url = f"{base_url}&stationID={station_id}&Year={year}&Month={month}&Day=1"

    try:
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        with open(out_path, "wb") as f:
            f.write(resp.content)
        logging.info(f"İndirme başarılı: station={station_id}, year={year}, month={month}")
    except requests.exceptions.RequestException as e:
        logging.error(f"İndirme Hatası: station={station_id}, year={year}, month={month} => {e}")

def main():
    logging.info("Ingest süreci başladı.")
    os.makedirs(RAW_DATA_DIR, exist_ok=True)

    for sid in STATION_IDS:
        for year in YEARS:
            for m in MONTHS:
                filename = f"weather_station_{sid}_{year}_{m:02d}.csv"
                out_path = os.path.join(RAW_DATA_DIR, filename)
                download_weather_csv(sid, year, m, out_path)

    logging.info("Ingest süreci tamamlandı.")

if __name__ == "__main__":
    main()
