#!/usr/bin/env python3
# ---------------------------------------------------------
# ingest.py
#
# Purpose:
#   - Download raw weather CSV data for stations 26953 & 31688, years 2023 & 2024
#   - Save them to raw_data/ WITHOUT any data checks or modifications.
#
# No data checks here; we only do that in transform.py
# ---------------------------------------------------------

import os
import requests

RAW_DATA_DIR = "raw_data"
STATION_IDS = [26953, 31688]
YEARS = [2023, 2024]
MONTHS = range(1, 13)

def download_weather_csv(station_id, year, month, out_path):
    base_url = (
        "https://climate.weather.gc.ca/climate_data/bulk_data_e.html?"
        "format=csv&time=LST&timeframe=1&submit=Download+Data"
    )
    url = f"{base_url}&stationID={station_id}&Year={year}&Month={month}&Day=1"
    try:
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"Download failed for station={station_id}, year={year}, month={month} => {e}")
        return

    # Save unmodified
    with open(out_path, "wb") as f:
        f.write(resp.content)

def main():
    os.makedirs(RAW_DATA_DIR, exist_ok=True)
    for sid in STATION_IDS:
        for year in YEARS:
            for m in MONTHS:
                fname = f"weather_station_{sid}_{year}_{m:02d}.csv"
                out_path = os.path.join(RAW_DATA_DIR, fname)
                download_weather_csv(sid, year, m, out_path)

if __name__ == "__main__":
    main()
