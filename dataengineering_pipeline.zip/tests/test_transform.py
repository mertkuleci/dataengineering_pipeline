# tests/test_transform.py
import sqlite3
import os
import pytest
from transform import create_tables, check_coverage, record_issue, data_quality_issues

def setup_inmemory_db():
    """Helper to create an in-memory SQLite DB for testing."""
    conn = sqlite3.connect(":memory:")
    create_tables(conn)
    return conn

def test_coverage_check():
    """Test that coverage logic flags missing coverage if row_count is too low."""
    # 1) Prepare an in-memory DB
    conn = setup_inmemory_db()
    cur = conn.cursor()

    # 2) Insert sample data: year=2024, month=1 (31 days => 31*24=744 rows)
    # Let's only insert 100 rows => coverage ~13%
    for i in range(100):
        cur.execute("""
            INSERT INTO weather_raw (station_name, year, month, temp_c)
            VALUES (?, ?, ?, ?)
        """, ("TEST_STATION", 2024, 1, 10.0))
    conn.commit()

    # Clear any old data_quality_issues
    data_quality_issues.clear()

    # 3) Run coverage check
    check_coverage(conn)

    # 4) We expect a MISSING_COVERAGE issue
    # Because 100 vs. expected 744 => coverage=~13.44%
    assert len(data_quality_issues) == 1, "Should have exactly 1 coverage issue flagged"
    issue = data_quality_issues[0]
    assert issue["issue_type"] == "MISSING_COVERAGE"
    assert "coverage=13" in issue["details"]  # quick partial match

    conn.close()
