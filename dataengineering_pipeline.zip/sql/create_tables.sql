DROP TABLE IF EXISTS geonames_dim;
DROP TABLE IF EXISTS weather_raw;

CREATE TABLE geonames_dim (
    id TEXT,
    name TEXT,
    language_code TEXT,
    language_href TEXT,
    syllabic TEXT,
    feature_id TEXT,
    feature_href TEXT,
    category TEXT,
    status_code TEXT,
    status_href TEXT,
    concise_code TEXT,
    concise_href TEXT,
    generic_code TEXT,
    generic_href TEXT,
    location TEXT,
    province_code TEXT,
    province_href TEXT,
    map TEXT,
    relevance INTEGER,
    accuracy INTEGER,
    latitude REAL,
    longitude REAL,
    decision TEXT
);

CREATE TABLE weather_raw (
    station_name TEXT,
    climate_id TEXT,
    longitude REAL,
    latitude REAL,
    date_time TEXT,
    year INTEGER,
    month INTEGER,
    day INTEGER,
    hour TEXT,
    temp_c REAL
);
