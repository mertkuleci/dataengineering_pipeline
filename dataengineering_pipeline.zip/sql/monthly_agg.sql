DROP TABLE IF EXISTS monthly_agg;

CREATE TABLE monthly_agg AS
SELECT
    station_name,
    climate_id,
    longitude,
    latitude,
    year,
    month,
    AVG(temp_c) AS temperature_celsius_avg,
    MIN(temp_c) AS temperature_celsius_min,
    MAX(temp_c) AS temperature_celsius_max
FROM weather_raw
GROUP BY station_name, climate_id, longitude, latitude, year, month;
