DROP TABLE IF EXISTS final_data;

CREATE TABLE final_data AS
SELECT
    w.station_name,
    w.climate_id,
    w.latitude,
    w.longitude,
    printf('%04d-%02d', w.year, w.month) AS date_month,
    g.feature_id,
    g.map,
    w.temperature_celsius_avg,
    w.temperature_celsius_min,
    w.temperature_celsius_max,
    w.temperature_celsius_yoy_avg
FROM monthly_agg_yoy w
LEFT JOIN geonames_dim g
  ON w.latitude = g.latitude
 AND w.longitude = g.longitude;
