DROP TABLE IF EXISTS monthly_agg_yoy;

CREATE TABLE monthly_agg_yoy AS
SELECT
    curr.station_name,
    curr.climate_id,
    curr.longitude,
    curr.latitude,
    curr.year,
    curr.month,
    curr.temperature_celsius_avg,
    curr.temperature_celsius_min,
    curr.temperature_celsius_max,
    (curr.temperature_celsius_avg - prev.temperature_celsius_avg) 
        AS temperature_celsius_yoy_avg
FROM monthly_agg curr
LEFT JOIN monthly_agg prev
     ON curr.station_name = prev.station_name
    AND curr.climate_id   = prev.climate_id
    AND curr.longitude    = prev.longitude
    AND curr.latitude     = prev.latitude
    AND curr.month        = prev.month
    AND curr.year         = prev.year + 1;
