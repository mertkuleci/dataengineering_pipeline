#!/usr/bin/env python3

import os
import sqlite3
import csv
import calendar
import logging
from glob import glob
from openpyxl import Workbook

# pandas + pyarrow for JSON ve Parquet
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format='[%(levelname)s] %(asctime)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

DB_FILE = "weather_db.sqlite"
RAW_DATA_DIR = "raw_data"
GEONAMES_FILE = "geonames.csv"
FINAL_OUTPUT = "final_output.csv"
DQ_EXCEL = "transform_data_quality.xlsx"
FINAL_OUTPUT_JSON = "final_output.json"
FINAL_OUTPUT_PARQUET = "final_output.parquet"
DQ_JSON = "transform_data_quality.json"
DQ_PARQUET = "transform_data_quality.parquet"

SQL_DIR = "sql"

data_quality_issues = []

def record_issue(issue_type, details):
    data_quality_issues.append({"issue_type": issue_type, "details": details})

def run_sql_file(conn, sql_file_path):
    if not os.path.isfile(sql_file_path):
        logging.error(f"SQL dosyası bulunamadı: {sql_file_path}")
        return
    with open(sql_file_path, "r", encoding="utf-8") as f:
        sql_script = f.read()
    conn.executescript(sql_script)

def load_geonames(conn):
    if not os.path.isfile(GEONAMES_FILE):
        record_issue("MISSING_GEONAMES", f"{GEONAMES_FILE} not found.")
        return
    cur = conn.cursor()
    with open(GEONAMES_FILE, mode="r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row["relevance"] = row.get("relevance", None)
            row["accuracy"] = row.get("accuracy", None)
            row["latitude"] = row.get("latitude", None)
            row["longitude"] = row.get("longitude", None)

            cur.execute("""
                INSERT INTO geonames_dim (
                    id, name, language_code, language_href, syllabic,
                    feature_id, feature_href, category,
                    status_code, status_href,
                    concise_code, concise_href,
                    generic_code, generic_href,
                    location, province_code, province_href,
                    map, relevance, accuracy, latitude, longitude, decision
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                row.get("id"),
                row.get("name"),
                row.get("language.code") or row.get("language_code"),
                row.get("language.href") or row.get("language_href"),
                row.get("syllabic"),
                row.get("feature.id") or row.get("feature_id"),
                row.get("feature.href") or row.get("feature_href"),
                row.get("category"),
                row.get("status.code") or row.get("status_code"),
                row.get("status.href") or row.get("status_href"),
                row.get("concise.code") or row.get("concise_code"),
                row.get("concise.href") or row.get("concise_href"),
                row.get("generic.code") or row.get("generic_code"),
                row.get("generic.href") or row.get("generic_href"),
                row.get("location"),
                row.get("province.code") or row.get("province_code"),
                row.get("province.href") or row.get("province_href"),
                row.get("map"),
                row.get("relevance"),
                row.get("accuracy"),
                row.get("latitude"),
                row.get("longitude"),
                row.get("decision")
            ))
    conn.commit()

def load_weather_raw(conn):
    cur = conn.cursor()
    csv_files = glob(os.path.join(RAW_DATA_DIR, "weather_station_*.csv"))
    logging.info(f"{len(csv_files)} adet CSV dosyası bulunuyor.")
    for fpath in csv_files:
        logging.info(f"Yükleniyor: {fpath}")
        with open(fpath, mode="r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                station_name = row.get("Station Name")
                climate_id   = row.get("Climate ID")
                long_        = row.get("Longitude (x)")
                lat_         = row.get("Latitude (y)")
                dt_          = row.get("Date/Time (LST)")
                year_        = row.get("Year")
                month_       = row.get("Month")
                day_         = row.get("Day")
                hour_        = row.get("Time (LST)")
                temp_        = row.get("Temp (°C)")

                def to_float(val):
                    try:
                        return float(val)
                    except:
                        return None
                def to_int(val):
                    try:
                        return int(float(val))
                    except:
                        return None

                long_val  = to_float(long_)
                lat_val   = to_float(lat_)
                year_val  = to_int(year_)
                month_val = to_int(month_)
                day_val   = to_int(day_)
                temp_val  = to_float(temp_)

                cur.execute("""
                    INSERT INTO weather_raw (
                        station_name, climate_id, longitude, latitude,
                        date_time, year, month, day, hour, temp_c
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    station_name,
                    climate_id,
                    long_val,
                    lat_val,
                    dt_,
                    year_val,
                    month_val,
                    day_val,
                    hour_,
                    temp_val
                ))
    conn.commit()

def check_nulls(conn):
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM weather_raw WHERE temp_c IS NULL;")
    c = cur.fetchone()[0]
    if c > 0:
        record_issue("NULL_TEMPS", f"{c} rows have null temperature.")

    cur.execute("SELECT COUNT(*) FROM weather_raw WHERE year IS NULL OR month IS NULL;")
    c2 = cur.fetchone()[0]
    if c2 > 0:
        record_issue("NULL_YEAR_MONTH", f"{c2} rows have null year or month.")

def check_outliers(conn):
    cur = conn.cursor()
    sql = """
        SELECT station_name, year, month,
               MIN(temp_c) AS min_temp,
               MAX(temp_c) AS max_temp
        FROM weather_raw
        GROUP BY station_name, year, month
        HAVING min_temp < -50 OR max_temp > 50
    """
    rows = cur.execute(sql).fetchall()
    for (st, yr, mo, mn, mx) in rows:
        record_issue("OUTLIERS", f"Station={st}, {yr}-{mo:02d}, min={mn}, max={mx}")

def check_coverage(conn):
    cur = conn.cursor()
    sql = """
        SELECT station_name, year, month, COUNT(*) AS row_count
        FROM weather_raw
        GROUP BY station_name, year, month
    """
    rows = cur.execute(sql).fetchall()
    for (st, yr, mo, rcount) in rows:
        if yr not in (2023, 2024) or not mo or mo < 1 or mo > 12:
            continue
        days_in_month = calendar.monthrange(yr, mo)[1]
        expected = days_in_month * 24
        if expected == 0:
            continue
        cov = (rcount / expected) * 100
        if cov < 80:
            record_issue("MISSING_COVERAGE",
                         f"Station={st}, {yr}-{mo:02d}, coverage={cov:.2f}%, rows={rcount}, expected={expected}")

def clean_data(conn):
    cur = conn.cursor()
    cur.execute("DELETE FROM weather_raw WHERE year NOT IN (2023, 2024);")
    cur.execute("DELETE FROM weather_raw WHERE temp_c IS NULL;")
    cur.execute("DELETE FROM weather_raw WHERE temp_c < -50 OR temp_c > 50;")
    conn.commit()

def export_data_quality_excel():
    wb = Workbook()
    ws = wb.active
    ws.title = "DataQuality"
    ws.append(["issue_type", "details"])
    for issue in data_quality_issues:
        ws.append([issue["issue_type"], issue["details"]])
    wb.save(DQ_EXCEL)

def main():
    logging.info("Transform başlıyor.")
    if os.path.exists(DB_FILE):
        os.remove(DB_FILE)

    conn = sqlite3.connect(DB_FILE)

    # create tables
    run_sql_file(conn, os.path.join(SQL_DIR, "create_tables.sql"))

    # load geonames
    load_geonames(conn)
    # load weather csv
    load_weather_raw(conn)
    # data quality checks
    check_nulls(conn)
    check_outliers(conn)
    check_coverage(conn)
    # temizleme
    clean_data(conn)
    # monthly agg
    run_sql_file(conn, os.path.join(SQL_DIR, "monthly_agg.sql"))
    # yoy
    run_sql_file(conn, os.path.join(SQL_DIR, "yoy_diff.sql"))
    # final_data
    run_sql_file(conn, os.path.join(SQL_DIR, "final_data.sql"))

    # final output => final_output.csv
    columns = [
        "station_name","climate_id","latitude","longitude","date_month",
        "feature_id","map","temperature_celsius_avg","temperature_celsius_min",
        "temperature_celsius_max","temperature_celsius_yoy_avg"
    ]
    cur = conn.cursor()
    cur.execute(f"SELECT {','.join(columns)} FROM final_data;")
    rows = cur.fetchall()

    with open(FINAL_OUTPUT, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(columns)
        for row in rows:
            writer.writerow(row)

    logging.info("final_output.csv oluşturuldu.")
    export_data_quality_excel()
    logging.info("Data Quality Excel dosyası oluşturuldu.")

    # Hem final_output.csv verisini hem de data_quality_issues verisini Parquet & JSON olarak da kaydet
    import pandas as pd

    # Final Output'u DataFrame'e dönüştür
    df_final = pd.DataFrame(rows, columns=columns)
    df_final.to_json(FINAL_OUTPUT_JSON, orient="records", force_ascii=False)
    df_final.to_parquet(FINAL_OUTPUT_PARQUET)
    logging.info("final_output.json ve final_output.parquet kaydedildi.")

    # data_quality_issues => DataFrame
    df_issues = pd.DataFrame(data_quality_issues)
    if not df_issues.empty:
        df_issues.to_json(DQ_JSON, orient="records", force_ascii=False)
        df_issues.to_parquet(DQ_PARQUET)
        logging.info("transform_data_quality.json ve transform_data_quality.parquet kaydedildi.")
    else:
        logging.info("Herhangi bir veri kalitesi uyarısı yok, issues listesi boş.")

    conn.close()
    logging.info("Transform tamamlandı.")

if __name__ == "__main__":
    main()
